#!/bin/sh
cd ./connector-bridge
./runConnectorBridge.sh &
cd ..
